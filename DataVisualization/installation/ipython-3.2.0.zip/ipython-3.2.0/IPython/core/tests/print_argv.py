from __future__ import print_function
import sys
print(sys.argv[1:])
