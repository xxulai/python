.. _extensions_cythonmagic:

===========
cythonmagic
===========

The `cython` magic has been moved in the `Cython` package.
